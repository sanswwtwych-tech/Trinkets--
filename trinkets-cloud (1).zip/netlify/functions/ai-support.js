const SYSTEM_SUPPORT = `Você é o Assistente IA oficial do Trinkets, um hub brasileiro de mini-ferramentas digitais. Responda sempre em português do Brasil, de forma clara, útil e objetiva. Você pode explicar como usar estas ferramentas: Gerador de Senhas, Conversor de Unidades, Caracteres/Palavras, Gerador de QR Code, Cronômetro e Timer, Bloco de Notas Rápido, Calculadora Científica, Gerador de Cores, Conversor de Moedas, Ferramenta de Texto, Tocador de Vídeo, Leitor de Áudio, Assistente IA e Central de Segurança. Quando uma ferramenta puder depender do navegador, URL direta ou permissões, explique essa limitação sem inventar. Não peça senhas, tokens, chaves de API, dados bancários ou outros segredos. Você é suporte de produto, não atendimento financeiro. Para segurança, apenas faça análise defensiva e recomendações de proteção. Não ensine invasão, exploração de vulnerabilidades, bypass de autenticação, malware, roubo de credenciais ou phishing.`;
const SYSTEM_SECURITY = `Você é o analista defensivo da Central de Segurança do Trinkets. Responda em português do Brasil. Analise somente riscos e sinais defensivos do conteúdo recebido e explique como o usuário pode se proteger. Não forneça instruções operacionais de ataque, exploração, bypass de autenticação, malware, roubo de credenciais ou phishing. Não transforme o conteúdo em um guia de ataque. Se houver suspeita de senha, token, chave de API ou dado bancário, recomende não compartilhar. Seja claro sobre incerteza: uma análise de texto não garante que algo seja seguro.`;

function json(body,status=200){return new Response(JSON.stringify(body),{status,headers:{"Content-Type":"application/json; charset=utf-8","Cache-Control":"no-store"}})}
function extractText(data){if(typeof data?.output_text==="string"&&data.output_text.trim())return data.output_text.trim();const parts=[];for(const item of data?.output||[]){for(const c of item?.content||[]){if(typeof c?.text==="string")parts.push(c.text)}}return parts.join("\n").trim()}
export default async (request)=>{
  if(request.method!=="POST")return json({error:"Método não permitido."},405);
  const key=process.env.OPENAI_API_KEY;
  if(!key)return json({error:"OPENAI_API_KEY não está configurada no Netlify."},500);
  let body;try{body=await request.json()}catch{return json({error:"JSON inválido."},400)}
  const mode=body?.mode==="security"?"security":"support";
  let messages=Array.isArray(body?.messages)?body.messages:[];
  messages=messages.filter(m=>m&&["user","assistant"].includes(m.role)&&typeof m.content==="string").slice(-12).map(m=>({role:m.role,content:m.content.slice(0,12000)}));
  if(!messages.length)return json({error:"Nenhuma mensagem válida."},400);
  if(messages.some(m=>m.content.length>12000))return json({error:"Mensagem muito grande."},400);
  const model=process.env.OPENAI_MODEL||"gpt-5";
  const payload={model,input:messages,instructions:mode==="security"?SYSTEM_SECURITY:SYSTEM_SUPPORT,max_output_tokens:700,store:false};
  try{
    const r=await fetch("https://api.openai.com/v1/responses",{method:"POST",headers:{"Authorization":`Bearer ${key}`,"Content-Type":"application/json"},body:JSON.stringify(payload)});
    const data=await r.json().catch(()=>({}));
    if(!r.ok)return json({error:data?.error?.message||"A API de IA retornou um erro."},502);
    const reply=extractText(data);
    if(!reply)return json({error:"A IA não retornou texto."},502);
    return json({reply});
  }catch(error){return json({error:"Falha ao conectar ao provedor de IA."},502)}
};
